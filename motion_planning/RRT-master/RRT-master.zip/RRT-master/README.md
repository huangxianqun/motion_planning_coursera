RRT (Rapidly-Exploring Random Trees)
=====
Masters in Computer Vision

2nd Semeter

Autonomous Robotics Lab

Sampling-based algorithms

Rapidly Exploring Random Tree (RRT)

My Lab Work

[Lab Paper](RRT.pdf)

[My Report](Report/RRT_Report.pdf)

Authors
=======
- **Emre Ozan Alkan**

Requirements
============
- Matlab R2013a or later.

Notes
============
- Tested on MATLAB: 8.1.0.604 (R2013a), Mac OS X 10.9.1 (Mavericks), Java 1.6.0_65

License
============
RRT (Rapidly-Exploring Random Trees) using [the MIT license](LICENSE).
